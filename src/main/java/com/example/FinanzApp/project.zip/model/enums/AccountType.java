package com.example.FinanzApp.model.enums;

public enum AccountType {
    BANK, VIRTUAL_WALLET, CASH;
}
